#include "InterruptControl.h"
#include "Scheduler.h"

void timerInit();
void timerStart();
void timerStop();
void timerReset();

void timerInterruptControl(uint8_t enable);
uint32_t timerValue();

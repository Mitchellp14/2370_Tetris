#include <stdint.h>

//#define LED_TOGGLE_EVENT (1 << 0)
//#define LED_DELAY_EVENT (1 << 1)
//#define BUTTON_POLL_EVENT (1 << 2)
//#define DEVICE_ID_AND_TEMP_EVENT (1<<3)

#define ROTATE_EVENT (1 << 0)
#define COUNT_EVENT (1<<1)
#define TOUCH_EVENT_RIGHT (1<<2)
#define TOUCH_EVENT_LEFT (1<<3)



uint32_t getScheduledEvents();

void addSchedulerEvent(uint32_t event);

void removeSchedulerEvent(uint32_t event);

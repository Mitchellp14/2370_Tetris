#include <stdbool.h>
#include "InterruptControl.h"
#include "stm32f4xx_hal.h"

#define BUTTON_PORT GPIOA
#define BUTTON_PIN_NUMBER 0
#define BUTTON_PRESSED 1
#define BUTTON_UNPRESSED 0

void ButtonInit();
void enableButtonClock();
bool buttonPress();
void interruptModeInit();


#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h> // For srand() and rand()
#include "stm32f4xx_hal.h"
//#include "LCD_Driver.h"

#define LCD_COLOR_WHITE         0xFFFF
#define LCD_COLOR_BLACK         0x0000
#define LCD_COLOR_GREY          0xF7DE
#define LCD_COLOR_BLUE          0x001F
#define LCD_COLOR_BLUE2         0x051F
#define LCD_COLOR_RED           0xF800
#define LCD_COLOR_MAGENTA       0xF81F
#define LCD_COLOR_GREEN         0x07E0
#define LCD_COLOR_CYAN          0x7FFF
#define LCD_COLOR_YELLOW        0xFFE0
#define LCD_COLOR_ORANGE		0xFD20
#define LCD_COLOR_PINK			0xFDDB

#define IPIECE_INDEX 0
#define OPIECE_INDEX 1
#define TPIECE_INDEX 2
#define SPIECE_INDEX 3
#define ZPIECE_INDEX 4
#define JPIECE_INDEX 5
#define LPIECE_INDEX 6

#define TETROMINO_SIZE 4

#define SPAWNX 4
#define SPAWNY 0

#define LEFT 1
#define RIGHT 0

typedef struct
{
	uint32_t color;
	//char shape;
	uint8_t grid[4][4];
	uint16_t x;
	uint16_t y;

	bool ghost;
}tetrisPiece_t;

void rngInit();

tetrisPiece_t setPiece(char piece);
tetrisPiece_t setGrid(tetrisPiece_t piece, uint16_t pieceIndex);
tetrisPiece_t rotatePiece(tetrisPiece_t piece);
void gameTimerInit();

bool canRotate(tetrisPiece_t currPiece);
bool canMoveDown(tetrisPiece_t currPiece);
bool checkCollision(tetrisPiece_t currPiece, uint8_t left);
void updateBoard(tetrisPiece_t currPiece);

tetrisPiece_t randomPiece();

#ifndef INTERRUPTCONTROLLER_H
#define INTERRUPTCONTROLLER_H

#include "stm32f4xx_hal.h"
#include <stdint.h>

//#define APB2_BASE_ADDR (0x40010000)
//#define EXTI_BASE_ADDR (APB2_BASE_ADDR + 0x3C00)
//#define EXTI ((EXTI_RegDef_t*) EXTI_BASE_ADDR)
//
//#define NVIC_ISER0 ((volatile uint32_t*) 0xE000E100)
//#define NVIC_ICER0 ((volatile uint32_t*) 0xE000E180)
//#define NVIC_ISPR0 ((volatile uint32_t*) 0xE000E200)
//#define NVIC_ICPR0 ((volatile uint32_t*) 0xE000E280)

#define EXTI0_IRQ_NUMBER 6
#define TIM5_IRQ_NUMBER 50

void IRQenableInterrupt(uint8_t IRQNumber);
void IRQdisableInterrupt(uint8_t IRQNumber);
void IRQclearPendingInterrupt(uint8_t IRQNumber);
void IRQsetPendingInterrupt(uint8_t IRQNumber);

void clearInterruptBit(uint16_t pin);


#endif

#include <stdint.h>
#include "InterruptControl.h"

void IRQenableInterrupt(uint8_t IRQNumber)
{

	HAL_NVIC_EnableIRQ(IRQNumber);
//	if(IRQNumber < 32)
//	{
//		*NVIC_ISER0 |= (1 << IRQNumber);
//	}
//	else
//	{
//		uint8_t properShift = IRQNumber % 32;
//		*NVIC_ISER0 |= (1 << properShift);
//	}
}
void IRQdisableInterrupt(uint8_t IRQNumber)
{
	HAL_NVIC_DisableIRQ(IRQNumber);
//	if(IRQNumber < 32)
//	{
//		*NVIC_ICER0 |= (1 << IRQNumber);
//	}
//	else
//	{
//		uint8_t properShift = IRQNumber % 32;
//		*NVIC_ICER0 |= (1 << properShift);
//	}

}
void IRQclearPendingInterrupt(uint8_t IRQNumber)
{
	HAL_NVIC_ClearPendingIRQ(IRQNumber);
//	if(IRQNumber < 32)
//	{
//		*NVIC_ICPR0 |= (1 << IRQNumber);
//	}
//	else
//	{
//		uint8_t properShift = IRQNumber % 32;
//		*NVIC_ICPR0 |= (1 << properShift);
//	}

}
void IRQsetPendingInterrupt(uint8_t IRQNumber)
{
	HAL_NVIC_SetPendingIRQ(IRQNumber);
//	if(IRQNumber < 32)
//	{
//		*NVIC_ISPR0 |= (1 << IRQNumber);
//	}
//	else
//	{
//		uint8_t properShift = IRQNumber % 32;
//		*NVIC_ISPR0 |= (1 << properShift);
//	}

}

void clearInterruptBit(uint16_t pin)
{
	EXTI->PR |= (1 << pin);

}

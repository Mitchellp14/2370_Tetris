//#include <stdint.h>
#include "Button_Driver.h"

void ButtonInit()
{
	GPIO_InitTypeDef ButtonConfig;

	ButtonConfig.Pin = GPIO_PIN_0;
	ButtonConfig.Mode = GPIO_MODE_INPUT;
	//ButtonConfig.OPType = GPIO_OUTPUT_TYPE_PP;
	ButtonConfig.Speed = GPIO_SPEED_HIGH;
	ButtonConfig.Pull = GPIO_NOPULL;
	ButtonConfig.Alternate = 0;
	//ButtonConfig.PinInterruptMode = NO_INTERRUPT;

	//enableButtonClock();
	HAL_GPIO_Init(GPIOA, &ButtonConfig);
}
//void enableButtonClock()
//{
//
//}
bool buttonPress()
{
	GPIO_PinState button = HAL_GPIO_ReadPin(GPIOA, BUTTON_PIN_NUMBER);

	return (button == BUTTON_PRESSED);
}

void interruptModeInit()
{
	GPIO_InitTypeDef ButtonConfig;

	ButtonConfig.Pin = GPIO_PIN_0;
	ButtonConfig.Mode = GPIO_MODE_IT_RISING;
	//ButtonConfig.OPType = GPIO_OUTPUT_TYPE_PP;
	ButtonConfig.Speed = GPIO_SPEED_HIGH;
	ButtonConfig.Pull = GPIO_NOPULL;
	ButtonConfig.Alternate = 0;
	//ButtonConfig.PinInterruptMode = FALLING_AND_RISING_INTERRUPT;

	HAL_GPIO_Init(GPIOA, &ButtonConfig);
	HAL_NVIC_EnableIRQ(EXTI0_IRQn);
}

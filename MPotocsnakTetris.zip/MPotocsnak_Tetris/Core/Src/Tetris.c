#include "Tetris.h"

//12Wx16D board with 2 deep walls on each side for edge cases +1 y for edge case
static uint8_t board[19][16] =
	{   {1,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1},
		{1,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1},
		{1,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1},
		{1,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1},
		{1,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1},
		{1,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1},
		{1,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1},
		{1,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1},
		{1,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1},
		{1,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1},
		{1,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1},
		{1,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1},
		{1,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1},
		{1,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1},
		{1,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1},
		{1,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1},
		{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
		{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
		{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1} };


const uint8_t tetrominoes[7][4][4] = {
    // I = 0
    {
        {0, 0, 0, 0},
        {1, 1, 1, 1},
        {0, 0, 0, 0},
        {0, 0, 0, 0}
    },
    // O = 1
    {
        {0, 0, 0, 0},
        {0, 1, 1, 0},
        {0, 1, 1, 0},
        {0, 0, 0, 0}
    },
    // T = 2
    {
        {0, 0, 0, 0},
        {0, 1, 0, 0},
        {1, 1, 1, 0},
        {0, 0, 0, 0}
    },
    // S = 3
    {
        {0, 0, 0, 0},
        {0, 1, 1, 0},
        {1, 1, 0, 0},
        {0, 0, 0, 0}
    },
    // Z = 4
    {
        {0, 0, 0, 0},
        {1, 1, 0, 0},
        {0, 1, 1, 0},
        {0, 0, 0, 0}
    },
    // J = 5
    {
        {0, 0, 0, 0},
        {1, 0, 0, 0},
        {1, 1, 1, 0},
        {0, 0, 0, 0}
    },
    // L = 6
    {
        {0, 0, 0, 0},
        {0, 0, 1, 0},
        {1, 1, 1, 0},
        {0, 0, 0, 0}
    }
};

static RNG_HandleTypeDef hRNG;
void rngInit()
{
	__HAL_RCC_RNG_CLK_ENABLE();


	hRNG.Instance = RNG;
	HAL_RNG_Init(&hRNG);
}
tetrisPiece_t setPiece(char piece)
{
	tetrisPiece_t Piece;

	if(piece == 'I')
	{
		Piece.color = LCD_COLOR_CYAN;
		Piece = setGrid(Piece, IPIECE_INDEX);
	}
	else if(piece == 'O')
	{
		Piece.color = LCD_COLOR_YELLOW;
		Piece = setGrid(Piece, OPIECE_INDEX);
	}
	else if(piece == 'J')
	{
		Piece.color = LCD_COLOR_PINK;
		Piece = setGrid(Piece, JPIECE_INDEX);
	}
	else if(piece == 'S')
	{
		Piece.color = LCD_COLOR_RED;
		Piece = setGrid(Piece, SPIECE_INDEX);
	}
	else if(piece == 'L')
	{
		Piece.color = LCD_COLOR_ORANGE;
		Piece = setGrid(Piece, LPIECE_INDEX);
	}
	else if(piece == 'Z')
	{
		Piece.color = LCD_COLOR_GREEN;
		Piece = setGrid(Piece, ZPIECE_INDEX);
	}
	else if(piece == 'T')
	{
		Piece.color = LCD_COLOR_MAGENTA;
		Piece = setGrid(Piece, TPIECE_INDEX);
	}

	Piece.x = SPAWNX;
	Piece.y = SPAWNY;

	return Piece;
}


tetrisPiece_t setGrid(tetrisPiece_t piece, uint16_t pieceIndex)
{
	for(int i = 0; i < TETROMINO_SIZE; i++)
	{
		for(int j = 0; j < TETROMINO_SIZE; j++)
		{
			piece.grid[i][j] = tetrominoes[pieceIndex][i][j];
		}
	}

	return piece;
}

tetrisPiece_t rotatePiece(tetrisPiece_t piece)
{
	uint8_t temp[4][4] = {0};

	//transpose
	for(int i = 0; i < TETROMINO_SIZE; i ++)
	{
		for(int j = 0; j < TETROMINO_SIZE; j++)
		{
			temp[i][j] = piece.grid[j][i];
		}
	}

	//reverse columns
	for(int i = 0; i < TETROMINO_SIZE; i++)
	{
		int start = 0;
		int end = TETROMINO_SIZE-1;

		while(start<end)
		{
			uint8_t tempswap = temp[start][i];
			temp[start][i] = temp[end][i];
			temp[end][i] = tempswap;
			start++;
			end--;
		}
	}

	//set piece grid to rotated grid
	for(int i = 0; i < TETROMINO_SIZE; i++)
		{
			for(int j = 0; j < TETROMINO_SIZE; j++)
			{
				piece.grid[i][j] = temp[i][j];
			}
		}

	return piece;
}

bool canMoveDown(tetrisPiece_t currPiece)
{

	for(int i = 0; i < 4; i++)
	{
		for(int j = 0; j<4; j++)
		{
			if((currPiece.grid[i][j]==1) && (board[currPiece.y+i+1][currPiece.x+2+j]==1))
			{
				return false;
			}
		}
	}

	return true;
}
tetrisPiece_t randomPiece()
{
	uint32_t randomNum = 0;
	tetrisPiece_t piece;

	HAL_RNG_GenerateRandomNumber(&hRNG, &randomNum);
	uint16_t num = (randomNum % 7) + 1;


	if(num == 1)
	{
		piece = setPiece('I');
	}
	else if(num == 2)
	{
		piece = setPiece('O');
	}
	else if(num == 3)
	{
		piece = setPiece('Z');
	}
	else if(num == 4)
	{
		piece = setPiece('L');
	}
	else if(num == 5)
	{
		piece = setPiece('S');
	}
	else if(num == 6)
	{
		piece = setPiece('J');
	}
	else
	{
		piece = setPiece('T');
	}

	return piece;
}
bool canRotate(tetrisPiece_t currPiece)
{
	tetrisPiece_t tempPiece = currPiece;
	tempPiece = rotatePiece(tempPiece);
	for(int i = 0; i < 4; i++)
	{
		for(int j = 0; j<4 ; j++)
		{
			if((tempPiece.grid[i][j]==1) && (board[tempPiece.y+i][tempPiece.x+j+2]==1))
			{
				return false;
			}
		}
	}
	return true;
}
bool checkCollision(tetrisPiece_t currPiece, uint8_t left)
{
	tetrisPiece_t tempPiece = currPiece;
	if(left)
	{
		if(tempPiece.x == 0) return false;
		tempPiece.x--;
	}
	else
	{
		tempPiece.x++;
	}

	for(int i = 0; i < 4; i++)
	{
		for(int j = 0; j < 4; j++)
		{
			if((tempPiece.grid[i][j]==1) && (board[tempPiece.y+i][tempPiece.x+j+2]==1))
			{
				return false;
			}
		}
	}
	return true;
}
void updateBoard(tetrisPiece_t currPiece)
{
	for(int i = 0; i < 4; i++)
	{
		for(int j = 0; j < 4; j++)
		{
			board[currPiece.y + i][currPiece.x+2+j] = currPiece.grid[i][j];
		}
	}
}

#include "Timer.h"

static TIM_HandleTypeDef hTim5;
void timerInit()
{
	__HAL_RCC_TIM5_CLK_ENABLE();
	hTim5.Instance = TIM5;
	hTim5.Init.CounterMode = TIM_COUNTERMODE_UP;
	hTim5.Init.Period = 999999;
	hTim5.Init.Prescaler = 83;
	hTim5.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	HAL_TIM_Base_Init(&hTim5);

	//TIM5->ARR = 0xF423F;
	TIM5->EGR = TIM_EGR_UG;


	timerInterruptControl(ENABLE);
}

void timerStart()
{
	HAL_TIM_Base_Start(&hTim5);
}

void timerStop()
{
	HAL_TIM_Base_Stop(&hTim5);
}

void timerInterruptControl(uint8_t enable)
{
	if(enable)
	{
		 __HAL_TIM_ENABLE_IT(&hTim5, TIM_IT_UPDATE);
		 HAL_NVIC_EnableIRQ(TIM5_IRQn);
	}
	else
	{
		 __HAL_TIM_DISABLE_IT(&hTim5, TIM_IT_UPDATE);
		 HAL_NVIC_DisableIRQ(TIM5_IRQn);
	}
}

uint32_t timerValue()
{
	 return __HAL_TIM_GET_COUNTER(&hTim5);
}

void TIM5_IRQHandler()
{

	HAL_NVIC_DisableIRQ(TIM5_IRQn);

	__HAL_TIM_CLEAR_IT(&hTim5, TIM_IT_UPDATE);

	addSchedulerEvent(COUNT_EVENT);

	HAL_NVIC_EnableIRQ(TIM5_IRQn);
}
